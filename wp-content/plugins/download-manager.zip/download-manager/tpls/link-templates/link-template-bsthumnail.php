<!-- WPDM Link Template: Card -->

    <ul class="list-group wpdm-lt-card" style="margin: 0 0 15px 0">
        <li class="list-group-item">
            <a href="[page_url]" style="display: block;margin: 5px 0">
            [thumb_500x250]
            </a>
        </li>
        <li class="list-group-item">
            <h4 style="padding: 0px;margin:0px;">[page_link]</h4>
        </li>
        <li class="list-group-item">
            <span class="badge">[file_size]</span> File Size
        </li>
        <li class="list-group-item">
            <span class="badge">[download_count]</span> Downloads
        </li>
        <li class="list-group-item">
            [download_link]
        </li>
    </ul>

 