<!-- WPDM Link Template: Panel 1/3 -->
<div class="col-md-4">
<div class="panel panel-default">
    <div class="panel-body">
<div class="media">
    <a class="pull-left" href="[page_url]">
    [thumb_60x60]
    </a>
    <div class="media-body">
    <h4 class="media-heading" style="padding-top: 0px;border:0px;margin: 0px;height: 20px;overflow: hidden">[page_link]</h4>
    <i style="margin: 4px 0 0 5px;opacity:0.5" class="fa fa-th-large"></i> [file_size]<Br/>

    </div>
</div>
</div>
    <div class="panel-footer"><div class="pull-left" style="line-height: 30px;"><i style="margin: 2px 0 0 5px;" class="icon icon-download-alt"></i> [download_count] downloads</div>  <div class="pull-right">[download_link_popup]</div><div style="clear: both"></div></div>
</div>
</div>
<style>
.panel-footer .wpdm-download-link {
    font-size: 10px !important;
    padding: 3px 14px 5px !important;
}
</style>
