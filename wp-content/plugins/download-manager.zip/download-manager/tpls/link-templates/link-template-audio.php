<!-- WPDM Link Template: With Audio Preview -->
<div class="w3eden">
<div class="media thumbnail">
    <div class="pull-left">
    [play_button]
    </div> 
    <div class="media-body">
    <h4 class="media-heading">[page_link]</h4>
    <div class="btn-small" style="padding-left: 0px;">
    <i style="margin: 2px 0 0 0px;opacity:0.5" class="fa fa-th-large"></i> [file_size] <i style="margin: 2px 0 0 5px;opacity:0.5" class="fa fa-download-alt"></i> [download_count] downloads
    </div>

    </div>
</div>
</div>