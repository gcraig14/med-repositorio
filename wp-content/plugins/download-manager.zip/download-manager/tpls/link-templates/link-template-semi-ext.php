<!-- WPDM Link Template: 1 Column, Extended --> 
<div class="col-md-4 link-template">
[thumb_350x250]

<div style="clear: both;"></div>
<h3 style="margin: 10px 0;padding: 0;font-size: 12pt"><a href="[page_url]"><strong>[title]</strong></a></h3>
<table class="table-striped table-bordered table">
<tbody>
<tr><td>Version</td><td>[version]</td></tr>
<tr><td>Size</td><td>[file_size]</td></tr>
<tr><td>Last Updated</td><td>[update_date]</td></tr>
<tr><td colspan="2">[download_link]</div></td></tr>
</tbody></table>    
</div> 
 


