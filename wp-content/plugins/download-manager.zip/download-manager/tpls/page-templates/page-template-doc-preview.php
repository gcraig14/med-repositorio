<!-- WPDM Template: Single Column with Doc Preview  -->
<style type="text/css">.more_previews_a{display: block;float: left;margin-right: 6px;}</style>
<div class="row">
<div class="col-md-12">
    [doc_preview]
</div>
<div class="col-md-12">
<table class="table table-bordered">
<tbody>
<tr><td>Version</td><td>[version]</td></tr>
<tr><td>Download</td><td>[download_count]</td></tr>
<tr><td>Size</td><td>[file_size]</td></tr>
<tr><td>Create Date</td><td>[create_date]</td></tr>
<tr><td>Last Updated</td><td>[update_date]</td></tr>
</tbody></table>
</div>
</div>
<div class="row">
<div class="col-md-12">
[description]
<br />
[file_list]
<br>
[download_link_extended]
</div>

</div>



