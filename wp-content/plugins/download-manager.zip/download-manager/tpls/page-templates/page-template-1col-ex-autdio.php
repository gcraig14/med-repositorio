<!-- WPDM Template: Single Column, Extended, PlayList -->
 <div class="row">

<div class="col-md-12">
<table class="table table-bordered">
<tbody>
<tr><td>Version</td><td>[version]</td></tr>
<tr><td>Categories</td><td>[categories]</td></tr>
<tr><td>Download</td><td>[download_count]</td></tr>
<tr><td>Size</td><td>[file_size]</td></tr>
<tr><td>Create Date</td><td>[create_date]</td></tr>
<tr><td>Last Updated</td><td>[update_date]</td></tr>
<tr><td colspan="2">[thumb_gallery_40x40]</td></tr>
</tbody></table>    
</div> 
<div class="col-md-12">
<div class="panel panel-default">
    [play_list]
    <div class="panel-footer">[download_link]</div>
</div>
</div>

<div class="col-md-12">      
[description]  
</div>

</div>

<style>.panel audio{ margin-bottom: -6px !important; padding: 6px; } .wpdm-filelist th:last-child, .wpdm-filelist td:last-child{ width: 60px; text-align: center; }</style>